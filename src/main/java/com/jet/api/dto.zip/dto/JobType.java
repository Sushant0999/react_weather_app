package com.jet.api.dto;

public enum JobType {
    TRANSFER,
    PUBLIC,
    PRIVATE
}
