package com.jet.api.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Action {
    private String actionId;
    private String createdOn;
    private String jobId;
    private DataDTO data;
    private String lastModifiedOn;
    private String nextActionIds;
    private String type;
}
